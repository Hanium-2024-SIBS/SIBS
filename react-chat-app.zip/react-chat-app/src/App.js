// src/App.js
import React from 'react';
import ChatRoom from './components/ChatRoom';
import './App.css';

function App() {
  return (
    
    <div className="App">
      <section>
        <ChatRoom />
      </section>
    </div>
  );
}

export default App;
